import React from "react";
import aboutImage from "../assests/aboutImage.png";

function About() {
    return (
        <section className="relative bg-white overflow-x-hidden">
            <div className="container mx-auto px-6 sm:px-8 lg:px-12 py-12 md:py-20">
                <div className="flex flex-col md:flex-row items-center justify-center gap-10 lg:gap-16">


                    <div className="w-full md:w-1/3 text-center mt-10 md:text-left">
                        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-blue-600 mb-3 sm:mb-4">
                            Welcome to smart Academy
                        </h1>
                        <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                            We aim to empower learners worldwide through innovative and
                            practical education solutions.
                        </p>
                    </div>

                    <div
                        className="mt-6 relative flex justify-center items-center shadow-lg w-[90%] sm:w-[380px] md:w-[380px] lg:w-[421px] h-[450px] sm:h-[500px] md:h-[600px] lg:h-[648px]"
                        style={{
                            borderTopLeftRadius: "210.5px",
                            borderTopRightRadius: "210.5px",
                            borderBottomRightRadius: "50px",
                            borderBottomLeftRadius: "50px",
                            overflow: "hidden",
                            background: "linear-gradient(180deg, #FFB6C1 0%, #FF3C8A 100%)",
                        }}
                    >
                        <img
                            src={aboutImage}
                            alt="About Smart Academy"
                            className="w-full h-full object-cover opacity-90"
                        />
                    </div>

                    <div className="w-full md:w-1/3 text-center md:text-left">
                        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-blue-600 mb-3 sm:mb-4">
                            Our Mission
                        </h1>
                        <p className="text-gray-600 text-sm sm:text-base mb-6 sm:mb-8 leading-relaxed">
                            Lorem ipsum dolor sit amet, consectetur elit. Etiam condimentum leo sed nisi vehicula, fringilla ante tincidunt. Sed sit amet
                        </p>


                        <div
                            className="mx-auto md:mx-0 flex flex-col sm:flex-row justify-between items-center bg-pink-50 rounded-xl shadow-md px-6 py-6 sm:px-8 sm:py-4 divide-y sm:divide-y-0 sm:divide-x divide-gray-300"
                            style={{
                                width: "100%",
                                maxWidth: "420px",
                                opacity: 1,
                            }}
                        >

                            <div className="flex flex-col items-center sm:px-4 py-3 sm:py-0">
                                <h3 className="text-xl sm:text-2xl font-bold text-blue-600">10+</h3>
                                <p className="text-gray-700 text-sm font-medium">Years Experience</p>
                            </div>


                            <div className="flex flex-col items-center sm:px-4 py-3 sm:py-0">
                                <h3 className="text-xl sm:text-2xl font-bold text-blue-600">29+</h3>
                                <p className="text-gray-700 text-sm font-medium">Total Courses</p>
                            </div>


                            <div className="flex flex-col items-center sm:px-4 py-3 sm:py-0">
                                <h3 className="text-xl sm:text-2xl font-bold text-blue-600">50K+</h3>
                                <p className="text-gray-700 text-sm font-medium">Active Students</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    );
}

export default About;
