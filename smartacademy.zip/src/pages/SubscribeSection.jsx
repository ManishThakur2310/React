import { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function SubscribeSection() {
  const [email, setEmail] = useState("");

  const handleSubscribe = () => {
    if (email.trim() === "") {
      toast.error("Please enter your email address!");
      return;
    }
    toast.success(`Subscribed successfully with: ${email}`);
    setEmail(""); 
  };

  return (
    <section className="bg-pink-600 min-h-screen flex items-center justify-center text-gray-800 px-6 py-20 md:px-16">
      <div className="text-center w-full">
        <h1 className="w-[90%] md:w-[60%] mx-auto text-3xl md:text-4xl font-bold text-white mb-6">
          Ignite Your Child's Potential — Take the Leap with an Online Course
        </h1>

        <div className="flex flex-col md:flex-row justify-center items-center gap-4">
          <input
            type="email"
            placeholder="Your email address..."
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-[90%] md:w-[40%] h-[3em] rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <button
            onClick={handleSubscribe}
            className="bg-blue-400 text-white px-8 py-3 rounded-full font-semibold hover:bg-pink-500 transition"
          >
            Subscribe
          </button>
        </div>
        <ToastContainer position="top-center" autoClose={2000} />
      </div>
    </section>
  );
}
