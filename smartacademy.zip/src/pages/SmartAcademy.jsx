import React from "react";


import kidsAerobicCourse from "../assests/Kids-Aerobic-Course.png";
import kidsGoGreen from "../assests/Kids-Go-Green-Course.png";
import kidsCraft from "../assests/Kids-Craft-&-Art-Course.png";
import kidsLanguage from "../assests/Kids-Languages-Course.png";
import kidsMusic from "../assests/Kids-Music-Course.png";
import kidsChef from "../assests/Kids-Chef-Course.png";
import kidsSceince from "../assests/kids-sceince-course.png";
import kidsSwimming from "../assests/Kids-Swimming-Course.png";

import chidlren1 from "../assests/children-1.png";
import chidlren2 from "../assests/children-2.png";
import chidlren3 from "../assests/children-3.png";
import chidlren4 from "../assests/children-4.png";
import chidlren5 from "../assests/children-5.png";

import article1 from "../assests/Article-1.png";
import article2 from "../assests/Article-2.png";
import article3 from "../assests/Article-3.png";
function SmartAcademy() {

    const courses = [
        { image: kidsSceince, title: "Kids Science Course" },
        { image: kidsAerobicCourse, title: "Kids Aerobic Course" },
        { image: kidsGoGreen, title: "Kids Go Green Course" },
        { image: kidsCraft, title: "Kids Craft & Art Course" },
        { image: kidsLanguage, title: "Kids Language Course" },
        { image: kidsMusic, title: "Kids Music Course" },
        { image: kidsChef, title: "Kids Chef Course" },
        { image: kidsSwimming, title: "Kids Swimming Course" },
    ];

    const children = [
        { image: chidlren1, title: "Park Jee" },
        { image: chidlren2, title: "Jasmine Vandervort" },
        { image: chidlren3, title: "Jasmine Vandervort" },
        { image: chidlren4, title: "Husna mawadus" },
        { image: chidlren5, title: "Jacob Kozey" },

    ];

    const article = [
        { image: article1, title: "The Benefits of Enrolling Kids in Online Courses" },
        { image: article2, title: "Unlock Your Child's Potential with Online Courses for Kids" },
        { image: article3, title: "Engage and Inspire The Power of Online Courses for Kids" }

    ]

    return (
        <>
            <section className="min-h-screen bg-white text-gray-800 px-6 md:px-16 pt-32 pb-16">

                <div className="text-center mb-12">
                    <h1 className="w-[90%] md:w-[30%] mx-auto text-3xl md:text-4xl font-bold text-blue-400">
                        Our Featured Courses at Smart Academy
                    </h1>
                </div>


                <div className="flex flex-wrap justify-center gap-8">
                    {courses.map((course, index) => (
                        <div
                            key={index}
                            className="w-full sm:w-[45%] lg:w-[22%] bg-white border border-gray-200 shadow-md rounded-2xl  hover:shadow-lg transition duration-300"
                        >
                            <img
                                src={course.image}
                                alt={course.title}
                                className="w-full h-56 object-cover rounded-xl mb-4"
                            />
                            <h2 className="text-lg font-semibold text-center text-blue-600">
                                {course.title}
                            </h2>
                        </div>
                    ))}
                </div>
            </section>
            <section className="min-h-screen bg-white text-gray-800 px-6 md:px-16 pt-32 pb-16">
                <div className="text-center mb-10">
                    <h1 className="w-[90%] md:w-[40%] mx-auto text-3xl md:text-4xl font-bold text-blue-400">
                        Our Testimonial at Smart Academy
                    </h1>
                </div>

                <div className="flex flex-wrap justify-center gap-6">
                    {children.map((child, index) => (
                        <div
                            key={index}
                            className="w-full sm:w-[80%] md:w-[45%] lg:w-[30%] xl:w-[25%] bg-white border border-gray-200 rounded-2xl shadow-md overflow-hidden flex flex-col md:flex-row items-center p-4 hover:shadow-lg transition"
                        >
                            <img
                                src={child.image}
                                alt={child.title}
                                className="w-24 h-24 md:w-28 md:h-28 rounded-full object-cover mb-4 md:mb-0 md:mr-4"
                            />
                            <div className="text-center md:text-left">
                                <h2 className="font-semibold text-blue-400">{child.title}</h2>
                                <p className="text-sm text-gray-600 mt-2">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam,
                                    beatae quae necessitatibus.
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>


            <section className="min-h-screen bg-white text-gray-800 px-6 md:px-16 pt-32 pb-16">

                <div className="text-center mb-12">
                    <h1 className="w-[90%] md:w-[30%] mx-auto text-3xl md:text-4xl font-bold text-blue-400">
                        Articles And Insight
                    </h1>
                </div>


                <div className="flex flex-wrap justify-center align-center gap-8">
                    {article.map((course, index) => (
                        <div
                            key={index}
                            className="w-full sm:w-[45%] lg:w-[22%] bg-white border border-gray-200 shadow-md rounded-2xl  hover:shadow-lg transition duration-300"
                        >
                            <img
                                src={course.image}
                                alt={course.title}
                                className="w-full h-56 object-cover rounded-xl mb-4 p-2"
                            />
                            <div>
                                <h2 className="text-lg font-semibold text-center text-blue-600 mb-4 p-2">
                                    {course.title}
                                </h2>
                            </div>
                            <div>
                                <p className="mb-4 text-center ">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </p>
                            </div>
                            <div className="text-center mb-4">
                                <button className="bg-[#FF3C8A] text-white px-8 py-3 rounded-full font-semibold hover:bg-pink-500 transition">
                                    Explore More
                                </button>
                            </div>

                        </div>
                    ))}
                </div>
            </section>
        </>
    );
}

export default SmartAcademy;
