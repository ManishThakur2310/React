import React from "react";
import { GiTeacher } from "react-icons/gi";
import { TbFileCertificate } from "react-icons/tb";
import { FaLaptopCode, FaHandshake } from "react-icons/fa";

function Courses() {
  const courses = [
    {
      icon: <GiTeacher />,
      title: "Teachers Professional",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
    {
      icon: <FaLaptopCode />,
      title: "Online Course",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
    {
      icon: <TbFileCertificate />,
      title: "Certificate Course",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
    {
      icon: <FaHandshake />,
      title: "Better Value",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
  ];

  return (
    <section className="min-h-screen bg-white text-gray-800 px-6 md:px-16 pt-32 pb-16">
    
      <div className="w-[90%] md:w-[40%] mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-blue-600">
          Smart Academy offers services like
        </h1>
      </div>

      <div className="flex flex-wrap justify-center items-start gap-8 mb-12">
        {courses.map((course, index) => {
          const iconColor =
            index % 2 === 0 ? "text-blue-600" : "text-[#FF3C8A]";

          return (
            <div
              key={index}
              className="bg-white border border-gray-200 shadow-md rounded-2xl p-6 hover:shadow-lg transition duration-300 text-center flex flex-col items-center w-full sm:w-[45%] lg:w-[22%]"
            >
              <div className={`text-5xl mb-4 ${iconColor}`}>{course.icon}</div>
              <h2 className="text-xl font-semibold mb-3">{course.title}</h2>
              <p className="text-gray-600 text-sm">{course.description}</p>
            </div>
          );
        })}
      </div>

      <div className="text-center">
        <button className="bg-[#FF3C8A] text-white px-8 py-3 rounded-full font-semibold hover:bg-pink-500 transition">
          Explore More
        </button>
      </div>
    </section>
  );
}

export default Courses;
