import React from 'react';
import image from "../assests/image.png";
import About from './About';
import Courses from './Courses';
import SmartAcademy from './SmartAcademy';
import SubscribeSection from './SubscribeSection';

function Home() {
  return (
   <>
    <div
      className="relative flex flex-col items-center justify-center h-screen text-center bg-cover bg-center px-6 sm:px-10 lg:px-20"
      style={{
        backgroundImage: `linear-gradient(to right, rgba(0,0,0,0.9), rgba(0,0,0,0.4)), url(${image})`,
      }}
    >
      <div
        className="absolute top-[280px] left-[70px] max-w-[990px] text-white space-y-6 sm:space-y-8 z-20 text-left"
      >
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold drop-shadow-lg leading-snug lg:leading-tight">
          Achieve your future <br className="hidden sm:block" /> With Smart Academy
        </h1>

        <p className="text-base sm:text-lg text-gray-200 max-w-xl">
          Learn, explore, and grow your skills with our interactive courses and smart academy resources.
        </p>

        <button className="mt-4 sm:mt-6 bg-[#FF3C8A] text-white font-semibold px-5 sm:px-6 py-2.5 sm:py-3 rounded-full hover:bg-pink-500 transition">
          Explore Courses
        </button>
      </div>

    </div>
    <About/>
    <Courses/>
    <SmartAcademy/>
    <SubscribeSection/>
   </>
  );
}

export default Home;
