import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isTransparent, setIsTransparent] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > window.innerHeight * 0.9) {
        setIsTransparent(false);
      } else {
        setIsTransparent(true);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 px-6 md:px-10 py-4 flex items-center justify-between transition-all duration-300 ${
        isTransparent
          ? 'bg-transparent text-white'
          : 'bg-white text-[#FF3C8A] shadow-md'
      }`}
    >
      <button
        className={`md:hidden focus:outline-none ${
          isTransparent ? 'text-white' : 'text-[#FF3C8A]'
        }`}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        {menuOpen ? <X size={28} /> : <Menu size={28} />}
      </button>

      <div
        className={`${
          menuOpen ? 'flex' : 'hidden'
        } md:flex flex-col md:flex-row items-center justify-center md:justify-between w-full gap-6 md:gap-40 lg:gap-80 xl:gap-96 mt-4 md:mt-0`}
      >

        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6 text-base md:text-lg font-medium">
          <a
            href="#home"
            className={`transition ${
              isTransparent
                ? 'text-white hover:text-pink-300'
                : 'text-[#FF3C8A] hover:text-pink-400'
            }`}
            onClick={() => setMenuOpen(false)}
          >
            Home
          </a>

          <a
            href="#about"
            className={`transition ${
              isTransparent
                ? 'text-white hover:text-pink-300'
                : 'text-[#FF3C8A] hover:text-pink-400'
            }`}
            onClick={() => setMenuOpen(false)}
          >
            About
          </a>

          <a
            href="#courses"
            className={`transition ${
              isTransparent
                ? 'text-white hover:text-pink-300'
                : 'text-[#FF3C8A] hover:text-pink-400'
            }`}
            onClick={() => setMenuOpen(false)}
          >
            Course
          </a>
        </div>

        <div className="flex items-center space-x-4 text-base md:text-lg font-bold mt-4 md:mt-0">
          <a
            href="#smart-academy"
            className={`transition ${
              isTransparent
                ? 'text-white hover:text-pink-300'
                : 'text-[#FF3C8A] hover:text-pink-400'
            }`}
            onClick={() => setMenuOpen(false)}
          >
            Smart Academy
          </a>
        </div>

        <div className="flex items-center space-x-4 text-base md:text-lg font-medium mt-4 md:mt-0">
          <a href="#courses" onClick={() => setMenuOpen(false)}>
            <button
              className={`font-semibold px-5 py-2 md:px-6 md:py-3 rounded-full transition ${
                isTransparent
                  ? 'bg-[#FF3C8A] text-white hover:bg-pink-500'
                  : 'bg-[#FF3C8A] text-white hover:bg-pink-500'
              }`}
            >
              Explore Courses
            </button>
          </a>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
