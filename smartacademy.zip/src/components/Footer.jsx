import React from "react";
import { FaFacebookF, FaInstagram } from "react-icons/fa";
import { LiaBehance } from "react-icons/lia";
import { IoIosBasketball } from "react-icons/io";

function Footer() {
  return (
    <footer className="bg-blue-400 text-white px-8 md:px-20 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start gap-10 md:gap-20">
        <div className="md:w-1/3">
          <h2 className="text-2xl font-bold mb-3">Smart Academy</h2>
          <p className="text-sm leading-relaxed mb-4">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil omnis numquam doloribus possimus cum at, quae minus quas quia nobis voluptates quos esse amet maxime, iusto quis doloremque perferendis temporibus?
          </p>
          <div className="flex space-x-4">
            <a href="/" className="hover:text-blue-200 transition">
              <LiaBehance size={20} />
            </a>
            <a href="/" className="hover:text-blue-200 transition">
              <IoIosBasketball size={20} />
            </a>
            <a href="/" className="hover:text-blue-200 transition">
              <FaFacebookF size={20} />
            </a>
            <a href="/" className="hover:text-blue-200 transition">
              <FaInstagram size={20} />
            </a>
          </div>
        </div>

        <div className="md:w-1/3">
          <h3 className="text-xl font-semibold mb-3">Quick Links</h3>
          <p className="hover:text-blue-200 cursor-pointer">Course</p>
          <p className="hover:text-blue-200 cursor-pointer">Our Service</p>
          <p className="hover:text-blue-200 cursor-pointer">Contact us</p>
          <p className="hover:text-blue-200 cursor-pointer">Blog</p>
        </div>

        <div className="md:w-1/3">
          <h3 className="text-xl font-semibold mb-3">Course</h3>
          <p className="hover:text-blue-200 cursor-pointer">Music Course</p>
          <p className="hover:text-blue-200 cursor-pointer">Art and Craft Course</p>
          <p className="hover:text-blue-200 cursor-pointer">Aerobic Course</p>
          <p className="hover:text-blue-200 cursor-pointer">Science Course</p>
        </div>
      </div>

      <div className="border-t border-white/30 mt-10 pt-6 text-center text-sm">
        © {new Date().getFullYear()} Smart Academy. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
